package com.sujitxansh.app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * This screen is shown only after a correct login.
 *
 * To add your actual file/content later:
 *   1. Put the file in app/src/main/assets/ (create that folder) — e.g. assets/myfile.pdf
 *   2. In this class, open/display it however fits the file type
 *      (open a PDF viewer, play a video, show an image, start a download, etc.)
 *   3. Replace the placeholder TextView in activity_content.xml with your actual
 *      content view (PDF viewer, VideoView, ImageView, WebView, etc.)
 *
 * No admin panel, no account generation, no expiry logic lives here —
 * just a single gate in front of whatever you put in this screen.
 */
public class ContentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        try {
    android.content.Context context = getApplicationContext();
    java.io.InputStream in = context.getAssets().open("SUJIT X ANSH.apk");
    java.io.File outFile = new java.io.File(context.getExternalFilesDir(null), "SUJIT X ANSH.apk");
    java.io.OutputStream out = new java.io.FileOutputStream(outFile);
    byte[] buffer = new byte[1024];
    int read;
    while ((read = in.read(buffer)) != -1) {
        out.write(buffer, 0, read);
    }
    in.close();
    out.flush();
    out.close();

    android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
    android.net.Uri apkUri = androidx.core.content.FileProvider.getUriForFile(
        context, context.getPackageName() + ".provider", outFile);
    intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
    intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
    startActivity(intent);
} catch (Exception e) {
    e.printStackTrace();
}

    }
}
