package com.sujitxansh.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // --- Fixed login credentials ---
    // Change these two values to whatever you want the app's login to be.
    private static final String VALID_USERNAME = "BIHARI";
    private static final String VALID_PASSWORD = "777";
    // --------------------------------

    private EditText editUsername;
    private EditText editPassword;
    private TextView textError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editUsername = findViewById(R.id.edit_username);
        editPassword = findViewById(R.id.edit_password);
        textError = findViewById(R.id.text_error);
        Button btnLogin = findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptLogin();
            }
        });
    }

    private void attemptLogin() {
        String user = editUsername.getText().toString().trim();
        String pass = editPassword.getText().toString();

        if (user.equals(VALID_USERNAME) && pass.equals(VALID_PASSWORD)) {
            textError.setVisibility(View.INVISIBLE);
            startActivity(new Intent(LoginActivity.this, ContentActivity.class));
            finish();
        } else {
            textError.setVisibility(View.VISIBLE);
        }
    }
}
